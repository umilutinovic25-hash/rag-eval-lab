# Nedelja 7 — obavezni eksperiment M5

Ovaj paket je kod checkpointa 45b8172, a ne napredni HEAD. Nema embeddinga, Ollama ni LLM-a.

1. Python 3.12: python3.12 -m venv .venv
2. Aktivacija: . .venv/bin/activate (Windows: .venv\Scripts\activate)
3. pip install -r requirements.txt
4. python -m pytest — očekivano 19 passed
5. python -m src.eval_runner --out results/reproduced-after.json — očekivano 7/12
6. python -m src.eval_compare evidence/before.json results/reproduced-after.json
   Očekivano Fixed E06, Regressed none, promenjeno samo CURRENT_ONLY, isti SHA-256.
7. python -m src.cli --question "How many days per week can I work remotely?" --show-retrieved

REPORT_BEFORE_AFTER.md je obavezni izveštaj. evidence/ sadrži pre/posle JSON, poređenje,
diff, testove i CLI provere. docs/change-spec.md prethodi implementaciji u istoriji repoa.

Komentar drugog para nije dostavljen do roka (odeljak 9 izveštaja).
Autor je Uroš Milutinović, koji je radio samostalno i potvrdio ličnu proveru.
Slanje nije potvrđeno. Priloženi nacrti nisu poslati.
Ovo nije zvanični šablon tutora.
